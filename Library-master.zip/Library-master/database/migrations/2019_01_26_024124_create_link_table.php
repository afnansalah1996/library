<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateLinkTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('link', function (Blueprint $table) {
          $table->increments('id');
          $table->string('title');
          $table->string('url')->default('');
          $table->string('icon')->default('');
          $table->string('route')->default('');
          $table->integer('parent_id');
          $table->boolean('new_window')->default(0);
          $table->boolean('show_in_menu')->default(1);
          $table->integer('order_id')->default(1);
          $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('link');
    }
}
