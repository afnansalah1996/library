@extends('layouts._bslayout')
@section('title',$title)
@section('content')



    <!-- Main Content -->
    <div class="container">
        <div class="alert alert-danger">
        This user has been disabled from system admin
        </div>
    </div>

@endsection()
