<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>Articles</title>
<link href="/Homepage/css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="/Homepage/js/jquery.min.js"></script>
<!-- Custom Theme files -->
<!--theme-style-->
<link href="/Homepage/css/style.css" rel="stylesheet" type="text/css" media="all" />
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Mattress Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--fonts-->
<link href='//fonts.googleapis.com/css?family=Lato:100,300,400,700,900' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900' rel='stylesheet' type='text/css'><!--//fonts-->
<!-- start menu -->
<link href="/Homepage/css/memenu.css" rel="stylesheet" type="text/css" media="all" />
<script type="text/javascript" src="/Homepage/js/memenu.js"></script>
<script>$(document).ready(function(){$(".memenu").memenu();});</script>
<script src="/Homepage/js/simpleCart.min.js"> </script>
</head>
<body>
<!--header-->
<div  class="header">
	<div class="header-top">
		<div class="container">
			<div class="social">
				<ul>
					<li><a href="https://www.facebook.com"><i class="facebok"> </i></a></li>
					<li><a href="https://www.twiter.com"><i class="twiter"> </i></a></li>
					<li><a href="https://www.instegram.com"><i class="inst"> </i></a></li>
					<li><a href="https://www.google.com"><i class="goog"> </i></a></li>
						<div class="clearfix"></div>
				</ul>
			</div>
			<div class="header-left">

				<div class="search-box">
					<div id="sb-search" class="sb-search">
						<form action="#" method="post">
							<input class="sb-search-input" placeholder="Enter your search term..." type="search"  id="search">
							<input class="sb-search-submit" type="submit" value="">
							<span class="sb-icon-search"> </span>
						</form>
					</div>
				</div>

<!-- search-scripts -->
					<script src="/Homepage/js/classie.js"></script>
					<script src="/Homepage/js/uisearch.js"></script>
						<script>
							new UISearch( document.getElementById( 'sb-search' ) );
						</script>
					<!-- //search-scripts -->

				<div class="ca-r">
					<div class="cart box_1">
						<a href="checkout.html">
						<h3> <div class="total">


            </div> </h3>

						</a>

					</div>
				</div>
					<div class="clearfix"> </div>
			</div>

		</div>
		</div>
		<div class="container">
			<div class="head-top" style="height:35px;">
				<div class="logo">
					<h1><img style=" border-radius: 15%; height:45px; " src="/Homepage/images/cart.png" alt="img" /></h1>
				</div>
		  <div class=" h_menu4">
				<ul class="memenu skyblue">

          <li><a class="color4" href="/home">Home</a></li>




				      <li><a class="color8" href="#">Catrgory</a>
				      	<div style="width:200px;" class="mepanel">

								<div  class="h_nav">
									<ul>
										<li><a  href="/category/7">Religious</a></li>
										<li><a  href="/category/4">Politician</a></li>
										<li><a  href="/category/5">Social</a></li>
										<li><a  href="/category/6">Economic</a></li>
										<li><a  href="/category/8">Sports</a></li>
										<li><a  href="/category/9">Local</a></li>
										<li><a  href="/category/10">International</a></li>
										<li><a  href="/category/11">Artistic</a></li>
										<li><a  href="/category/12">News</a></li>



									</ul>
								</div>
							</div>


					</li>

				<li><a class="color4" href="{{ route('login') }}">Login</a></li>
        <li><a class="color4" href="{{ route('register') }}">Register</a></li>
				<li><a class="color6" href="/users/contact">Contact</a></li>
			  </ul>
			</div>

				<div class="clearfix"> </div>
		</div>
		</div>
	</div>
	<div class="banner">
		<div class="container">
			  <script src="/Homepage/js/responsiveslides.min.js"></script>
  <script>
    $(function () {
      $("#slider").responsiveSlides({
      	auto: true,
      	nav: true,
      	speed: 500,
        namespace: "callbacks",
        pager: true,
      });
    });
  </script>
			<div  id="top" class="callbacks_container">
			<ul class="rslides" id="slider">
			    <li>

						<div class="banner-text">
							<h3> This Articles That   </h3>
						<p>Published recintly and its very important because have alot of information to all categories of ages , so read it !.</p>

						</div>

				</li>
				<li>

						<div class="banner-text">
							<h3>The Articles Are </h3>
						<p>Popular belief Contrary to , Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature .</p>


						</div>

				</li>
				<li>
						<div class="banner-text">
							<h3> Our Page Has </h3>
						<p>Lorem Ipsum is not simply random text. Contrary to popular belief, It has roots in a piece of classical Latin literature from 45 BC.</p>


						</div>

				</li>
			</ul>
		</div>

	</div>
	</div>


	<!---->
  @yield('content')

<div class="footer w3layouts ">
				<div class="container  mt-100">
			<div class="footer-top-at w3">

				<div class="col-md-3 amet-sed w3l">
				<h4>MORE INFO</h4>
				<ul class="nav-bottom">
						<li><a href="#">How to order</a></li>
						<li><a href="contact.html">Location</a></li>
						<li><a href="#">Membership</a></li>
					</ul>
				</div>
				<div class="col-md-3 amet-sed w3ls">
					<h4>CATEGORIES</h4>
					<ul class="nav-bottom">
						<li><a href="#">Duvets</a></li>
						<li><a href="#">Pillows</a></li>
						<li><a href="#">Protectors</a></li>
					</ul>

				</div>
				<div class="col-md-3 amet-sed agileits">
					<h4>NEWSLETTER</h4>
					<div class="stay agileinfo">
						<div class="stay-left wthree">
							<form action="#" method="post">
								<input type="text" placeholder="Enter your email " required="">
							</form>
						</div>
						<div class="btn-1 w3-agileits">
							<form action="#" method="post">
								<input type="submit" value="Subscribe">
							</form>
						</div>
							<div class="clearfix"> </div>
			</div>

				</div>
				<div class="col-md-3 amet-sed agileits-w3layouts">
				<h4>CONTACT US</h4>
					<p>Contrary to popular belief</p>
					<p>The standard chunk</p>
					<p>office :  +12 34 995 0792</p>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
		<div class="footer-class w3-agile">
		<p>© 2017 Mattress . All Rights Reserved</p>
		</div>
		</div>
</body>
</html>
