@extends('layouts._bslayout')
@section('title',$title)
@section('content')



    <!-- Main Content -->
    <div class="container">
        <div class="alert alert-danger">
        You don't have access permission on this url
        </div>
    </div>

@endsection()
