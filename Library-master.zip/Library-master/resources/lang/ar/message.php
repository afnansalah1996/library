
<?php

return [


  'welcome'    => 'اهلا وسهلا بكم ',





];













?>
